<?php

namespace Drupal\recently_viewed_nodes\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

/**
 * Handles the recently viewed nodes request.
 */
class RecentlyViewedController extends ControllerBase {

  /**
   * Returns the recently viewed nodes.
   */
  public function getRecentlyViewedNodes(Request $request) {
    $node_ids = $request->request->get('nodes');
    if (empty($node_ids) || !is_array($node_ids)) {
      return new JsonResponse([], 400);
    }

    $node_storage = $this->entityTypeManager()->getStorage('node');
    $nodes = $node_storage->loadMultiple($node_ids);

    $output = [];
    foreach ($nodes as $node) {
      $output[] = [
        'title' => $node->label(),
        'url' => $node->toUrl()->toString(),
      ];
    }

    return new JsonResponse($output);
  }

}
