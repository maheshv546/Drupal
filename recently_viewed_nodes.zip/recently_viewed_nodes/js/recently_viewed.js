(function ($, Drupal) {
    Drupal.behaviors.recentlyViewedNodes = {
      attach: function (context, settings) {
        const storageKey = 'recently_viewed_nodes';
        const recentlyViewed = JSON.parse(localStorage.getItem(storageKey)) || [];
  
        if (recentlyViewed.length > 0) {
          $.ajax({
            url: '/recently-viewed-nodes',
            type: 'POST',
            data: { nodes: recentlyViewed },
            success: function (data) {
              $('#recently-viewed-nodes-block').html(data);
            },
            error: function () {
              console.error('Failed to load recently viewed nodes.');
            },
          });
        }
      },
    };
  })(jQuery, Drupal);
  