(function (Drupal, drupalSettings) {
    Drupal.behaviors.recentlyViewedNodes = {
      attach: function (context, settings) {
        const maxNodes = 10; // Max number of recently viewed nodes to store
        const storageKey = 'recently_viewed_nodes';
  
        // Get the current node ID from Drupal settings
        const currentNodeId = drupalSettings.path.currentPath.match(/node\/(\d+)/);
        if (!currentNodeId) return;
  
        const nodeId = currentNodeId[1];
  
        // Get recently viewed nodes from localStorage
        let recentlyViewed = JSON.parse(localStorage.getItem(storageKey)) || [];
  
        // Add the current node ID to the list if it’s not already present
        if (!recentlyViewed.includes(nodeId)) {
          recentlyViewed.unshift(nodeId); // Add to the beginning of the list
        }
  
        // Ensure the list doesn't exceed the maxNodes
        if (recentlyViewed.length > maxNodes) {
          recentlyViewed.pop();
        }
  
        // Save back to localStorage
        localStorage.setItem(storageKey, JSON.stringify(recentlyViewed));
      },
    };
  })(Drupal, drupalSettings);
  