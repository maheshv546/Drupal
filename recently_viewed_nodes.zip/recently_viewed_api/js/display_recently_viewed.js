(function (Drupal) {
    Drupal.behaviors.displayRecentlyViewed = {
      attach: function (context, settings) {
        const storageKey = 'recently_viewed_nodes';
        const recentlyViewed = JSON.parse(localStorage.getItem(storageKey)) || [];
  
        if (recentlyViewed.length > 0) {
          const nodesContainer = document.querySelector('#recently-viewed-nodes');
  
          recentlyViewed.forEach((nodeId) => {
            fetch(`/node/${nodeId}?_format=json`) // Fetch node details from REST API
              .then((response) => response.json())
              .then((data) => {
                // Render each node
                const nodeElement = document.createElement('div');
                nodeElement.innerHTML = `<a href="/node/${nodeId}">${data.title}</a>`;
                nodesContainer.appendChild(nodeElement);
              })
              .catch((error) => console.error('Error fetching node details:', error));
          });
        }
      },
    };
  })(Drupal);
  